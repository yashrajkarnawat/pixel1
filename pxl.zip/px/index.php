<!DOCTYPE html>
<html>
<head><link rel="icon" type="x-icon/image" href="to.jpg"><title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style type="text/css">
  table, th, td 
  {
    margin-left: 40%;
    padding-left: 2px;
    padding-right: 2px; 
  }
  * {
  box-sizing: border-box;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 25%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>   
</head>
<body>   
    <?php
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "pixel";
      $conn = mysqli_connect($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }
      ?>

      <div class="row">
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group A</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group B</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group C</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group D</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
      </div>

      <div class="row">
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group E</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group F</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group G</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
        <div class="column">
          <?php
            $sql = "select name from teams where `former champ` = 'Yes' order by rand() limit 1";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        <tr>
                          <th>Group H</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
          <?php
            $sql = "select name from teams where `former champ` = 'No' order by rand() limit 3";
            $result=mysqli_query($conn,$sql);
            if (mysqli_num_rows($result) > 0) {
                echo "<table>
                        ";
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . $row["name"]. "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
          ?>
        </div>
    <?php
      $conn->close();
    ?>
      
    
  </div>
</div>
</body>
</html>
