<?php
$a=$_POST['a1'];
$b=$_POST['a2'];
$c=$_POST['a3'];
$severname="localhost";
$username="root";
$password="";
$dbname="pixel";
$conn=mysqli_connect($severname,$username,$password,$dbname);
if(!$conn)
{
	die("connection failed:".mysqli_connect_error());
}
else
{
	$sql="insert into `teams`(`name`,`country`,`former champ`)values('$a','$b','$c');";
	$var=mysqli_query($conn,$sql);
	if($var)
	{
		header('location:admin.php');
	}
	else
	{
		echo "Error:".$sql."<br>".mysqli_error($conn);
	}
}
mysqli_close($conn);

?>