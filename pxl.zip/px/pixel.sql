-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2020 at 11:22 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pixel`
--

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `name` varchar(50) NOT NULL,
  `country` varchar(3) NOT NULL,
  `former champ` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`name`, `country`, `former champ`) VALUES
('Arsenal ', 'ENG', 'No'),
('Astana ', 'KAZ', 'No'),
('Atletico ', 'ESP', 'No'),
('Barcelona ', 'ESP', 'Yes'),
('BATE ', 'BLR', 'No'),
('Bayern ', 'GER', 'Yes'),
('Benfica ', 'POR', 'Yes'),
('Chelsea', 'ENG', 'Yes'),
('CSKA Moskva ', 'RUS', 'No'),
('Dinamo Zagreb ', 'CRO', 'No'),
('Dynamo Kyiv', 'UKR', 'No'),
('Galatasaray', 'TUR', 'No'),
('Gent ', 'BEL', 'No'),
('Juventus ', 'ITA', 'Yes'),
('Leverkusen ', 'GER', 'No'),
('Lyon', 'FRA', 'No'),
('M. Tel-Aviv ', 'ISR', 'No'),
('Malmo ', 'SWE', 'No'),
('Man. City ', 'ENG', 'No'),
('Man. United ', 'ENG', 'No'),
('Monchengladbach ', 'GER', 'No'),
('Olympiacos ', 'GRE', 'No'),
('Paris ', 'FRA', 'Yes'),
('Porto ', 'POR', 'No'),
('PSV', 'NED', 'Yes'),
('Real Madrid ', 'ESP', 'No'),
('Roma ', 'ITA', 'No'),
('Sevilla ', 'ESP', 'No'),
('Shakhtar Donetsk ', 'UKR', 'No'),
('Valencia ', 'ESP', 'No'),
('Wolfsburg ', 'GER', 'No'),
('Zenith ', 'RUS', 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
