<!DOCTYPE html>
<html>
<head><link rel="icon" type="x-icon/image" href="to.jpg"><title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>
input[type=text], input[type=date], input[type=email] {
    width: 25%;
    padding: 12px 50px;
    margin: 10px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}
</style>
</head>
<body>
<center>
<form action="team.php" method="POST">
   <center><legend style="color: black;"> ADD TEAMS </legend></center>
      <div class="col-md-12">
        <label><b>Team Name</b></label>&nbsp&nbsp   
        <input type="text" style="border-radius: 4px;" placeholder="Enter Team Name" name="a1" id="b1" required><br>
        <label><b>Country Name</b></label>&nbsp&nbsp 
        <input type="text" style="border-radius: 4px;" placeholder="Country" name="a2" id="b" required><br>
        <label><b>Former Champion</b></label>&nbsp&nbsp
        <select style="padding: 12px 4%; border-radius: 4px;" name="a3" id="b3" required="">
          <option><center>Select</center></option>
          <option><center>Yes</center></option>
          <option><center>No</center></option>  
        </select><br>
        <button type="submit" style="border-radius: 4px; text-align: center;
          width: 10%;
          padding: 12px;
          border: none;
          border-radius: 4px;
          margin: 5px 0;
          opacity: 0.85;
          display: inline-block;
          font-size: 17px;
          line-height: 20px;
          text-decoration: none;">Add</button>
      </div> 
</form></center>
<br><br>
    <!--Code Above-->
</div>
</body>
</html>
